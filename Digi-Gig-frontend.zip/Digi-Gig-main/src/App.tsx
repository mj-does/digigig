import React, { useState } from "react";
import WalletConnect from "./WalletConnect";
import "./styles.css";
import { motion } from "framer-motion";

function App() {
  const [userAddress, setUserAddress] = useState<string>("");
  const [started, setStarted] = useState(false);

  return (
    <div className="app-container">
      <header className="header">
        <div className="logo">● DigiGig</div>
        <nav>
          <ul>
            <li>
              <a href="#">Home</a>
            </li>
            <li>
              <a href="#">Dashboard</a>
            </li>
            <li>
              <a href="#">Upload</a>
            </li>
            <li>
              <a href="#">About</a>
            </li>
          </ul>
        </nav>
      </header>

      <motion.section
        className="hero"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="hero-text">
          <h1>DigiGig: Proof-of-Work for Freelancers</h1>
          <p>
            Upload, verify, and showcase your freelance journey using blockchain
            technology.
          </p>
          <button className="btn" onClick={() => setStarted(true)}>
            Get Started
          </button>
        </div>
        <div className="hero-img">
          <img
            src="/digigig.png"
            alt="DigiGig Logo"
            style={{
              width: "300px",
              borderRadius: "20px",
              boxShadow: "0 0 20px rgba(255,255,0,0.3)",
            }}
          />
        </div>
      </motion.section>

      {started && (
        <motion.section
          className="start-section"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <h2
            style={{
              textAlign: "center",
              color: "yellow",
              marginBottom: "0.5rem",
            }}
          >
            🔗 Connect Your Wallet
          </h2>
          <p
            style={{
              textAlign: "center",
              maxWidth: "600px",
              margin: "0 auto 1rem",
              color: "#ccc",
            }}
          >
            Connect your Web3 wallet to verify your identity and proceed with
            your journey.
          </p>
          <div style={{ marginTop: "1.5rem" }}>
            <WalletConnect onConnect={setUserAddress} />
          </div>
          {userAddress && (
            <motion.div
              className="wallet-confirmation"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              ✅ Wallet connected:{" "}
              <span className="wallet-id">{userAddress}</span>
            </motion.div>
          )}
        </motion.section>
      )}

      {started && userAddress && (
        <motion.section
          className="choose-role"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.7 }}
        >
          <h2
            style={{
              fontSize: "2rem",
              textAlign: "center",
              color: "yellow",
              textShadow: "0 0 6px #fff200",
              animation: "glow 1.5s ease-in-out infinite alternate",
            }}
          >
            Choose Your Role
          </h2>
          <p
            style={{
              textAlign: "center",
              color: "#ccc",
              fontSize: "1.1rem",
              marginBottom: "2rem",
            }}
          >
            Start your journey on DigiGig
          </p>
          <div className="feature-cards">
            <motion.div className="card" whileHover={{ scale: 1.05 }}>
              <img
                src="/freelancer.png"
                alt="Freelancer"
                className="role-image"
              />
              <h3>🚀 Join as Freelancer</h3>
              <p>Build your on-chain proof-of-work profile and earn trust.</p>
              <a
                href="/freelancer/dashboard.html"
                target="_blank"
                rel="noopener noreferrer"
              >
                <button className="btn">Enter Freelancer Dashboard</button>
              </a>
            </motion.div>
            <motion.div className="card" whileHover={{ scale: 1.05 }}>
              <img src="/client.png" alt="Client" className="role-image" />
              <h3>🧑‍💼 Join as Client</h3>
              <p>Hire verified talent and issue on-chain credentials.</p>
              <a
                href="/client/dashboard.html"
                target="_blank"
                rel="noopener noreferrer"
              >
                <button className="btn">Enter Client Dashboard</button>
              </a>
            </motion.div>
          </div>
        </motion.section>
      )}

      <motion.section
        className="about boxed-section"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.7 }}
      >
        <h2>What is DigiGig?</h2>
        <div className="box">
          <p>
            DigiGig is a decentralized platform for freelancers to prove their
            work authenticity. Upload deliverables, store them on IPFS, and
            build a verified on-chain portfolio that’s yours forever — no
            central authority, no compromise.
          </p>
        </div>
      </motion.section>

      <motion.section
        className="features"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.7 }}
      >
        <h2>✨ Key Features</h2>
        <div className="feature-cards">
          <motion.div className="card" whileHover={{ scale: 1.05 }}>
            <h3>🔐 SoulBound NFTs</h3>
            <p>
              Immutable, non-transferable credentials proving your
              contributions.
            </p>
          </motion.div>
          <motion.div className="card" whileHover={{ scale: 1.05 }}>
            <h3>🌐 IPFS Storage</h3>
            <p>Decentralized file uploads using secure gateways like Pinata.</p>
          </motion.div>
          <motion.div className="card" whileHover={{ scale: 1.05 }}>
            <h3>🧾 Professional Identity</h3>
            <p>Establish a blockchain-based digital resume & reputation.</p>
          </motion.div>
        </div>
      </motion.section>

      <footer className="footer">
        &copy; 2025 DigiGig by Liceria & Co. | Empowering Freelancers on Web3.
      </footer>
    </div>
  );
}

export default App;
